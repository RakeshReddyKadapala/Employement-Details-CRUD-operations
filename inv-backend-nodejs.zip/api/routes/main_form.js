const formvalues = require("../../models/main_form");

module.exports = function (router) {
    router.get("/test", async (req, res) => {
        res.json({ message: "Success!" })
    })

    router.post("/data", async (req, res) => {
        let newform = new formvalues(req.body)
        newform.save(function (err, note) {
            if (err) {
                return res.status(400).json(err)
            }
            res.status(200).json(note)
        })
    })

    router.get("/data", async (req, res) => {
        const form_list = await formvalues.find({}).lean().exec();
        res.status(200).json(form_list);
        // console.log(orders);
    })


    router.put("/editdata", (req, res) => {
        if (!req.body._id) {
            res.json({ success: false, message: "no data is provided" });
        } else {
            formvalues.findOne({ _id: req.body._id }, (err, inputvalues) => {
                if (err) {
                    res.json({ success: false, message: "not a valid data id" });
                } else {

                    inputvalues.executivename = req.body.executivename;
                    inputvalues.documentname = req.body.documentname;
                    inputvalues.events = req.body.events;


                    inputvalues.save((err) => {
                        if (err) {
                            res.json({ success: false, message: err });
                        } else {
                            res.json({ success: true, message: "data updated" });
                        }
                    });
                }
            });
        }
    });


    router.delete("/data/:id", function (req, res) {
        formvalues.findOne({ _id: req.params.id }, (err, inputvalues) => {
            if (err) {
                res.send(err)
            } else {
                inputvalues.remove((err, newNote) => {
                    if (err) {
                        res.send(err)
                    }
                    res.status(200).json(newNote)
                })
            }
        })
    })



}