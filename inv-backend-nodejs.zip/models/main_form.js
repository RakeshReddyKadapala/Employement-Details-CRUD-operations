const mongoose = require('mongoose');


const mainSchema = new mongoose.Schema({

    executivename: String,
    documentname: String,
    events: String,





})


module.exports = mongoose.model("data", mainSchema)